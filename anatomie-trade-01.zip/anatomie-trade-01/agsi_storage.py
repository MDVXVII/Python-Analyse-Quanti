"""
Anatomie d'un trade n°1 -- Analyse des stockages de gaz (GIE AGSI+)
==================================================================

Reproduit les chiffres des sections 1 et 2 de la note :
    - taux de remplissage actuel et comparaison avec les annees precedentes ;
    - injection nette moyenne sur 7 et 30 jours ;
    - projection du remplissage au 1er novembre ;
    - rythme d'injection necessaire pour atteindre un objectif ;
    - fichier stockage_ue.dat utilise pour la figure 1 (pgfplots).

Donnees : exports CSV de l'historique d'un pays ou de l'UE sur https://agsi.gie.eu
(source a citer obligatoirement : GIE AGSI+).

Usage :
    python agsi_storage.py --eu data/agsi_eu.csv --de data/agsi_de.csv
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


# ---------------------------------------------------------------------------
# 1. Chargement des donnees AGSI+
# ---------------------------------------------------------------------------

def load_agsi(path: Path) -> pd.DataFrame:
    """Charge un export CSV AGSI+ (separateur ';') et l'indexe par jour gazier."""
    df = pd.read_csv(path, sep=";")
    # Le nom exact de la colonne de date varie selon les exports : on la cherche
    date_col = next(c for c in df.columns if c.startswith("Gas Day Start"))
    df["date"] = pd.to_datetime(df[date_col])
    df = df.sort_values("date").set_index("date")
    # Injection nette = injection - soutirage (GWh/jour)
    df["net"] = df["Injection (GWh/d)"] - df["Withdrawal (GWh/d)"]
    return df


# ---------------------------------------------------------------------------
# 2. Indicateurs
# ---------------------------------------------------------------------------

def same_date_by_year(df: pd.DataFrame, month: int, day: int) -> pd.Series:
    """Taux de remplissage (%) a une meme date pour chaque annee disponible."""
    out = {}
    for year in sorted(df.index.year.unique()):
        ts = pd.Timestamp(year=year, month=month, day=day)
        if ts in df.index:
            out[year] = df.loc[ts, "Full (%)"]
    return pd.Series(out, name="Full (%)")


def projection(df: pd.DataFrame, target: pd.Timestamp, window: int) -> dict:
    """Projection lineaire du remplissage a la date cible, au rythme moyen
    d'injection nette des `window` derniers jours."""
    last = df.iloc[-1]
    days_left = (target - df.index[-1]).days - 1      # jours gaziers restants
    rate = df["net"].tail(window).mean()              # GWh/jour
    capacity = last["Technical Capacity (TWh)"]       # TWh
    stock = last["Gas in storage (TWh)"]              # TWh
    projected = (stock + rate * days_left / 1000) / capacity * 100
    return {"rate_gwh_d": rate, "days_left": days_left, "projected_pct": projected}


def required_rate(df: pd.DataFrame, target: pd.Timestamp, goal_pct: float) -> float:
    """Injection nette (GWh/jour) necessaire pour atteindre goal_pct a la date cible."""
    last = df.iloc[-1]
    days_left = (target - df.index[-1]).days - 1
    missing = goal_pct / 100 * last["Technical Capacity (TWh)"] - last["Gas in storage (TWh)"]
    return missing * 1000 / days_left


def seasonal_cycle(df: pd.DataFrame, current_year: int, n_years: int = 5) -> pd.DataFrame:
    """Remplissage hebdomadaire : moyenne des n annees precedentes, annee
    precedente et annee en cours (NaN pour les dates futures)."""
    s = df["Full (%)"]
    s = s[~((s.index.month == 2) & (s.index.day == 29))]          # annees bissextiles
    t = pd.DataFrame({"year": s.index.year, "md": s.index.strftime("%m-%d"), "v": s.values})
    p = t.pivot(index="md", columns="year", values="v")
    past = [y for y in range(current_year - n_years, current_year) if y in p.columns]
    out = pd.DataFrame({
        "moyenne": p[past].mean(axis=1),
        f"annee{current_year - 1}": p[current_year - 1],
        f"annee{current_year}": p[current_year],
    })
    # jour de l'annee (annee non bissextile de reference)
    out.index = [pd.Timestamp(f"2025-{md}").dayofyear for md in out.index]
    out.index.name = "jour"
    return out.iloc[::7].round(1)                                  # un point par semaine


# ---------------------------------------------------------------------------
# 3. Rapport
# ---------------------------------------------------------------------------

def report(name: str, df: pd.DataFrame, target: pd.Timestamp, goal_pct: float) -> None:
    last_date = df.index[-1]
    print(f"\n=== {name} -- donnees au {last_date:%d/%m/%Y} "
          f"(statut : {df['Status'].iloc[-1]}) ===")
    print(f"Remplissage actuel            : {df['Full (%)'].iloc[-1]:.1f} %")

    hist = same_date_by_year(df, last_date.month, last_date.day)
    print("Meme date, annees precedentes : "
          + ", ".join(f"{y} : {v:.1f} %" for y, v in hist.items()))

    for w in (7, 30):
        p = projection(df, target, w)
        print(f"Injection nette moyenne {w:>2} j  : {p['rate_gwh_d']:,.0f} GWh/j "
              f"-> projection au {target:%d/%m} : {p['projected_pct']:.1f} %")

    req = required_rate(df, target, goal_pct)
    ratio = req / df["net"].tail(7).mean()
    print(f"Rythme requis pour {goal_pct:.0f} %     : {req:,.0f} GWh/j "
          f"({ratio:.1f} fois le rythme des 7 derniers jours)")


def main() -> None:
    ap = argparse.ArgumentParser(description="Analyse des stockages de gaz AGSI+")
    ap.add_argument("--eu", type=Path, required=True, help="Export AGSI+ de l'UE")
    ap.add_argument("--de", type=Path, required=True, help="Export AGSI+ de l'Allemagne")
    ap.add_argument("--target", default="2026-11-01", help="Date cible (AAAA-MM-JJ)")
    ap.add_argument("--out", type=Path, default=Path("output"))
    args = ap.parse_args()

    target = pd.Timestamp(args.target)
    args.out.mkdir(exist_ok=True)

    eu = load_agsi(args.eu)
    de = load_agsi(args.de)

    report("Union europeenne", eu, target, goal_pct=90)
    report("Allemagne", de, target, goal_pct=70)

    # Donnees de la figure 1 (lisibles directement par pgfplots)
    cycle = seasonal_cycle(eu, current_year=eu.index[-1].year)
    path = args.out / "stockage_ue.dat"
    cycle.to_csv(path, sep=" ", na_rep="nan")
    print(f"\nFichier ecrit : {path.resolve()}")
    print("Source a citer : GIE AGSI+")


if __name__ == "__main__":
    main()
