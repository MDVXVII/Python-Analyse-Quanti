"""
Anatomie d'un trade #1 -- Call spread sur le TTF Nov26
=======================================================

Pricing d'un call spread (achat call K1, vente call K2) sur un future TTF
avec le modele de Black (1976), analyse du profil de gain et sensibilites.

Cas pedagogique et hypothetique. Pas un conseil d'investissement.

Donnees de marche (hypotheses, a mettre a jour) :
    - Future TTF Nov26 : 74,28 EUR/MWh, 21/09/2026, Barchart (ICE Endex, cours differe)
    - Echeance des options Nov26 : 27/10/2026 (36 jours)
    - Volatilite implicite : hypothese de 75 %

Usage :
    python ttf_call_spread.py
    python ttf_call_spread.py --F 74.28 --K1 80 --K2 90 --vol 0.75 --days 36
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from math import exp, log, sqrt
from pathlib import Path

import numpy as np
from scipy.stats import norm


# ---------------------------------------------------------------------------
# 1. Modele de Black (1976) pour une option europeenne sur future
# ---------------------------------------------------------------------------

def _d1_d2(F: float, K: float, sigma: float, T: float) -> tuple[float, float]:
    """Termes d1 et d2 du modele de Black."""
    d1 = (log(F / K) + 0.5 * sigma**2 * T) / (sigma * sqrt(T))
    return d1, d1 - sigma * sqrt(T)


def black76_call(F: float, K: float, sigma: float, T: float, r: float) -> float:
    """Prix d'un call europeen sur future : C = e^{-rT} [F N(d1) - K N(d2)]."""
    d1, d2 = _d1_d2(F, K, sigma, T)
    return exp(-r * T) * (F * norm.cdf(d1) - K * norm.cdf(d2))


def black76_greeks(F: float, K: float, sigma: float, T: float, r: float) -> dict:
    """Grecques d'un call sur future (delta par rapport a F, vega pour +1 pt de vol,
    theta par jour calendaire)."""
    d1, d2 = _d1_d2(F, K, sigma, T)
    df = exp(-r * T)
    delta = df * norm.cdf(d1)
    vega = df * F * norm.pdf(d1) * sqrt(T) / 100            # pour +1 point de vol
    theta_annual = (-df * F * norm.pdf(d1) * sigma / (2 * sqrt(T))
                    + r * black76_call(F, K, sigma, T, r))
    return {"delta": delta, "vega": vega, "theta": theta_annual / 365}


# ---------------------------------------------------------------------------
# 2. Le call spread
# ---------------------------------------------------------------------------

@dataclass
class CallSpread:
    F: float        # prix du future (EUR/MWh)
    K1: float       # strike du call achete
    K2: float       # strike du call vendu
    sigma: float    # volatilite implicite (ex. 0.75)
    days: int       # jours calendaires jusqu'a l'echeance des options
    r: float = 0.02 # taux sans risque, sert uniquement a actualiser

    @property
    def T(self) -> float:
        return self.days / 365

    @property
    def width(self) -> float:
        return self.K2 - self.K1

    def leg_prices(self, sigma: float | None = None) -> tuple[float, float]:
        s = self.sigma if sigma is None else sigma
        return (black76_call(self.F, self.K1, s, self.T, self.r),
                black76_call(self.F, self.K2, s, self.T, self.r))

    def premium(self, sigma: float | None = None) -> float:
        c1, c2 = self.leg_prices(sigma)
        return c1 - c2

    def payoff_at_expiry(self, F_T: np.ndarray) -> np.ndarray:
        """Resultat net a l'echeance, prime deduite (EUR/MWh)."""
        return (np.maximum(F_T - self.K1, 0)
                - np.maximum(F_T - self.K2, 0)
                - self.premium())

    def summary(self) -> dict:
        c1, c2 = self.leg_prices()
        p = c1 - c2
        g1 = black76_greeks(self.F, self.K1, self.sigma, self.T, self.r)
        g2 = black76_greeks(self.F, self.K2, self.sigma, self.T, self.r)
        _, d2_k1 = _d1_d2(self.F, self.K1, self.sigma, self.T)
        _, d2_k2 = _d1_d2(self.F, self.K2, self.sigma, self.T)
        return {
            "call_K1": c1,
            "call_K2": c2,
            "premium": p,
            "breakeven": self.K1 + p,
            "breakeven_move_pct": (self.K1 + p) / self.F - 1,
            "max_gain": self.width - p,
            "max_loss": p,
            "reward_risk": (self.width - p) / p,
            # Approximation : prime / largeur = proba risque-neutre (non actualisee)
            # de finir "dans la zone" du spread
            "implied_prob_approx": p / (self.width * exp(-self.r * self.T)),
            # Probabilites risque-neutres exactes de finir au-dessus de chaque strike
            "prob_above_K1": norm.cdf(d2_k1),
            "prob_above_K2": norm.cdf(d2_k2),
            "delta": g1["delta"] - g2["delta"],
            "vega": g1["vega"] - g2["vega"],
            "theta": g1["theta"] - g2["theta"],
        }


# ---------------------------------------------------------------------------
# 3. Exports (fichiers .dat lisibles par pgfplots) et graphiques de controle
# ---------------------------------------------------------------------------

def export_dat(path: Path, header: list[str], rows) -> None:
    with path.open("w") as f:
        f.write(" ".join(header) + "\n")
        for row in rows:
            f.write(" ".join(f"{v:.4f}" for v in row) + "\n")


def main() -> None:
    ap = argparse.ArgumentParser(description="Pricing Black-76 d'un call spread TTF")
    ap.add_argument("--F", type=float, default=74.28)
    ap.add_argument("--K1", type=float, default=80.0)
    ap.add_argument("--K2", type=float, default=90.0)
    ap.add_argument("--vol", type=float, default=0.75)
    ap.add_argument("--days", type=int, default=36)
    ap.add_argument("--r", type=float, default=0.02)
    ap.add_argument("--volume_mwh", type=float, default=100_000,
                    help="Volume illustratif pour les montants en euros")
    ap.add_argument("--out", type=Path, default=Path("output"))
    ap.add_argument("--no-plots", action="store_true")
    args = ap.parse_args()

    cs = CallSpread(args.F, args.K1, args.K2, args.vol, args.days, args.r)
    s = cs.summary()
    args.out.mkdir(exist_ok=True)

    # --- Rapport console --------------------------------------------------
    print(f"\nCall spread {cs.K1:g}/{cs.K2:g} sur TTF Nov26 "
          f"(F = {cs.F:.2f}, vol = {cs.sigma:.0%}, T = {cs.days} j)\n")
    print(f"  Call {cs.K1:g} achete   : {s['call_K1']:6.3f} EUR/MWh")
    print(f"  Call {cs.K2:g} vendu    : {s['call_K2']:6.3f} EUR/MWh")
    print(f"  Prime nette           : {s['premium']:6.3f} EUR/MWh")
    print(f"  Point mort            : {s['breakeven']:6.2f} "
          f"({s['breakeven_move_pct']:+.1%} vs F)")
    print(f"  Gain max / perte max  : {s['max_gain']:.2f} / {s['max_loss']:.2f}"
          f"  (ratio {s['reward_risk']:.2f})")
    print(f"  Proba implicite ~     : {s['implied_prob_approx']:.1%}")
    print(f"  P(F_T > {cs.K1:g}) / P(F_T > {cs.K2:g}) : "
          f"{s['prob_above_K1']:.1%} / {s['prob_above_K2']:.1%}")
    print(f"  Delta {s['delta']:.3f} | Vega {s['vega']:.3f} /pt vol "
          f"| Theta {s['theta']:.3f} /jour")
    v = args.volume_mwh
    print(f"\n  Pour {v:,.0f} MWh : prime {s['premium']*v:,.0f} EUR, "
          f"gain max {s['max_gain']*v:,.0f} EUR\n")

    # --- Slide 7 : profils de gain a l'echeance ----------------------------
    grid = np.arange(60, 105.01, 0.5)
    c_single = black76_call(cs.F, cs.K1, cs.sigma, cs.T, cs.r)
    fut = grid - cs.F
    call = np.maximum(grid - cs.K1, 0) - c_single
    spread = cs.payoff_at_expiry(grid)
    export_dat(args.out / "payoffs.dat", ["F", "future", "call", "spread"],
               zip(grid, fut, call, spread))

    # --- Slide 8 : sensibilite de la prime a la volatilite -----------------
    vols = np.arange(0.40, 1.201, 0.05)
    sens = [(vv * 100, *cs.leg_prices(vv), cs.premium(vv)) for vv in vols]
    export_dat(args.out / "vol_sensitivity.dat",
               ["vol", "callK1", "callK2", "spread"], sens)
    print("  Sensibilite a la volatilite :")
    for vv, c1, c2, p in sens:
        if round(vv) % 15 == 0:
            print(f"    vol {vv:4.0f} %  ->  prime {p:5.3f}  "
                  f"(call {cs.K1:g} {c1:5.2f}, call {cs.K2:g} {c2:5.2f})")

    # --- Resume pour le LaTeX ----------------------------------------------
    with (args.out / "summary.txt").open("w") as f:
        for k, val in s.items():
            f.write(f"{k} = {val:.6f}\n")

    if args.no_plots:
        return

    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(grid, fut, ls=":", lw=2, label=f"Future acheté à {cs.F:.2f}")
    ax.plot(grid, call, ls="--", lw=2, label=f"Call {cs.K1:g} seul")
    ax.plot(grid, spread, lw=2.5, label=f"Call spread {cs.K1:g}/{cs.K2:g}")
    ax.axhline(0, color="grey", lw=0.8)
    ax.set_xlabel("Prix du TTF Nov26 à l'échéance (EUR/MWh)")
    ax.set_ylabel("Gain / perte (EUR/MWh)")
    ax.set_ylim(-16, 22)
    ax.legend(frameon=False)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    fig.tight_layout()
    fig.savefig(args.out / "payoffs.png", dpi=150)

    fig, ax = plt.subplots(figsize=(8, 4.5))
    arr = np.array(sens)
    ax.plot(arr[:, 0], arr[:, 3], lw=2.5)
    ax.axvline(cs.sigma * 100, color="grey", ls="--", lw=1)
    ax.set_xlabel("Volatilité implicite (%)")
    ax.set_ylabel("Prime du call spread (EUR/MWh)")
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    fig.tight_layout()
    fig.savefig(args.out / "vol_sensitivity.png", dpi=150)
    print(f"  Fichiers ecrits dans {args.out.resolve()}")


if __name__ == "__main__":
    main()
