# Anatomie d'un trade n°1 — Call spread sur le TTF

Code Python de la note *« Anatomie d'un trade n°1 : structurer une vue haussière
de court terme sur le gaz européen »* (septembre 2026).

La note part de l'état des stockages de gaz européens pour construire, étape par
étape, un call spread 80/90 sur le contrat TTF Novembre 2026, pricé avec le
modèle de Black (1976).

## Contenu

| Fichier | Rôle | Sections de la note |
|---|---|---|
| `agsi_storage.py` | Analyse des stockages : remplissage, injections, projections au 1er novembre, données de la figure 1 | 1 et 2 |
| `ttf_call_spread.py` | Pricing Black-76 du call spread, grecques, probabilités implicites, sensibilité à la volatilité, profils de gain | 5 à 7 |

## Installation

```bash
pip install -r requirements.txt
```

## Utilisation

**1. Analyse des stockages.** Télécharger sur [agsi.gie.eu](https://agsi.gie.eu)
l'historique de l'UE et de l'Allemagne (export CSV), puis :

```bash
python agsi_storage.py --eu data/agsi_eu.csv --de data/agsi_de.csv
```

**2. Pricing du call spread.** Les paramètres par défaut sont ceux de la note
(F = 74,28 EUR/MWh, strikes 80/90, volatilité 75 %, 36 jours, taux 2 %) :

```bash
python ttf_call_spread.py
```

Tous les paramètres sont modifiables, par exemple :

```bash
python ttf_call_spread.py --F 76 --K1 80 --K2 90 --vol 0.8 --days 30
```

Les résultats sont écrits dans le dossier `output/` (fichiers `.dat` lisibles par
pgfplots, graphiques `.png`, résumé des chiffres).

## Modèle

Les options TTF portent sur un contrat future : on utilise le modèle de Black (1976),
version de Black-Scholes adaptée aux options sur futures.

```
C  = e^(-rT) [ F N(d1) - K N(d2) ]
d1 = [ ln(F/K) + σ²T/2 ] / (σ √T),   d2 = d1 - σ √T
```

Limite principale : une seule volatilité est appliquée aux deux strikes (le skew
du marché du gaz est ignoré).

## Sources

- Stockages : **GIE AGSI+** (mention obligatoire en cas de réutilisation des données).
- Prix du future TTF Nov26 : Barchart, ICE Endex, cours différé du 21/09/2026.
- Volatilité implicite et taux : hypothèses de l'auteur.

## Avertissement

Exercice pédagogique fondé sur des données publiques. Ce code et la note associée ne
constituent ni une recommandation d'investissement, ni une incitation à traiter.

Maximilien de Valleuil
